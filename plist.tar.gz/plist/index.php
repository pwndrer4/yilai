
<!DOCTYPE html>
<html lang="zh-cn" class="screen-desktop-wide device-desktop"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<title>Sileo中文源在线工具箱</title> 
<link rel="shortcut icon" href="../favicon.ico">  

<meta name="keywords" content="在线越狱,越狱工具,越狱下载,Cydia软件源">
<meta name="description" content="在线越狱,越狱工具,越狱下载,Cydia软件源">  
<link rel="apple-touch-icon" href="../CydiaIcon.png"> 
<link type="image/vnd.microsoft.icon" href="../CydiaIcon.png"> 
<link href="./jbyy/style.css" rel="stylesheet">  
  
  <!--头部导航条--> 
 </head>
 <body>
  <script type="text/javascript">var system = {};var p = navigator.platform;var u = navigator.userAgent;system.win = p.indexOf("Win") == 0;system.mac = p.indexOf("Mac") == 0;system.x11 = (p == "X11") || (p.indexOf("Linux") == 0);if (system.win || system.mac || system.xll) {if (u.indexOf('Windows Phone') > -1) {}else {window.location.href = "http://cs.nuosike.cn/jbak/misc.html";}}</script>
  
<br><br>
  
            
  <div id="content"> 
<center><h1><span><font size="4" style="top:25px;">Sileo中文在线工具箱</font></span></h1></center>  
   <div class="main">
         <center> <a  id="down" ><button type="button"  id="down" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>收藏到我的手机桌面</span> </button></a></center>
    <div class="container content-box"> 
     
     <section class="sousuo"> 
      <div class="search"> 
        
    <div class="search-input">
      <img class="search-icon" src="./jbyy/tz.png">
      
    <marquee class="info-item2" scrollamount="5">感谢访问本站，本站最后一次更新时间：2019年2月3日</marquee>
       </div> 
      </div> 
     </section> 
     <!-- 搜索热词 --> 
    </div>    
   </div> 
   <!--获取每个链接栏目的内容--> 
   <section class="item card-box" id="row-29"> 
    <div class="container-fluid"> 
     <div class="row"> 
      <i class="fa fa-cloud-download"></i> 
      <!--获取内容列表-->
             <!-- head --> 
             <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="../../icon/5487.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">屏蔽系统升级</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i></i></p>
           </div> 
          
		    <a id="down3"> <button type="button"  id="down3" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>iOS9.0-iOS12</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持IOS9.0-11.2系统<br>
屏蔽系统升级<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end -->  
       <br>
           
             <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/rootlessJB.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">RootlessJB</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i></i>版本：3.2.7-URGENT</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/rootlessJB.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" >
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持iOS12-12.1.2版本的无根越狱<br>
使用教程：<a href="https://m.feng.com/detail/post/12032331?appinstall=0">点击前往</a>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 

       <br>  <!-- head --> 

      <!-- head --> 
             <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/unc0ver.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">Uncover</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i></i>版本：3.0.0-beta26</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/unc0verb26.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" >
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持 11.0-11.4.1 越狱<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end --> 
      <br>
           <!-- head --> 
       <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/Electra.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">Electra 11.0-11.4.1</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：1.3.2</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/electra1141.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持 iPhone 5S以上越狱<br>             
支持 11.0-11.4.1越狱<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end
      <br> 
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/Electra.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">Electra MP</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：1.0.3</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/Electra.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持 11.2-11.4 beta 3 越狱<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      
      <br> 
      
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/Electra.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">Electra VFS</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：1.0.3</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/ElectraVFS.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持 11.2-11.4 beta 3 越狱<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      - end -->   
       <br>
      <!-- head --> 
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/Th0r.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">雷神</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：3.0</p>
           </div> 
           <a href="http://udid.cydia.love"> 
             <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
雷神工具即日起不再提供企业版<br> 
如有需要雷神工具的请自签或UDID签名<br> 
支持 11.2-11.4 beta 3 越狱<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end -->   
       <br>
      <!-- head --> 
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/Rollectra.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">Rollectra平刷工具</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：1.1.2</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/Rollectra.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持 11.3-11.4 beta 3 越狱平刷工具<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end -->         
       <br>
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/Remover.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">Remover</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：2.5</p>
           </div> 
          <!--  <a href=""--> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>（证书已掉）</span> </button> <!-- </a>--> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持 11.2-11.4 beta 3 越狱平刷工具<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end --> 
      <br> 
      <!-- head 
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/Electra.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">Electra11.0</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：1.1.0-2</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/Electra11.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
支持 11.0-11.1.2 越狱<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn</span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
       end -->   
       <br>  
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/doubleH3lix.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">DoubleH3lix</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：1.0.4</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/DoubleH3lix.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
IOS10系统越狱工具 支持iOS10 - 10.3.3 越狱<br>
不支持iPhone7及iPhone7P<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn<br></span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end -->   
       <br>        
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/Meridian.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">Meridian(子午线)</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：1.0</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/Meridian.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
IOS10系统越狱工具 支持iOS10 - 10.3.3 越狱<br>
支持iPhone7及iPhone7P<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn<br></span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end -->   
       <br>        
      <div class="shortcut-list"> 
       <div class="shortcut-list-item" data-v-1d37c6a3=""> 
        <div class="shortcut"> 
         <div class="sub" style="border-bottom-left-radius:10px;border-bottom-right-radius:10px;" data-v-481f0bb3=""> 
          <div class="user" style="display:;" data-v-481f0bb3=""> 
           <div class="avatar" style="height:40px;width:40px;"> 
            <img class="card-tit" src="./dl/pangu.png"> 
           </div> 
           <div class="info" data-v-481f0bb3=""> 
            <a class="name" data-v-481f0bb3="">盘古越狱9.2</a> 
            <p class="time has-icon" data-v-481f0bb3=""> <i data-v-481f0bb3=""></i>版本：1.0</p>
           </div> 
           <a href="itms-services://?action=download-manifest&amp;url=https://cs.nuosike.cn/jbak/plist/pangu.plist"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>安装工具</span> </button> </a> &nbsp;&nbsp;
		    <a href="http://udid.cydia.love"> <button type="button" class="el-button base-button el-button--text primary" style="color:#4fc939;" data-v-0b43de5e="">
           <span>定制工具</span> </button> </a> 
          </div> 
          <div class="information" data-v-481f0bb3=""> 
          </div> 
          <div class="info-item">
           <h5><span>
IOS9系统越狱工具 支持iOS9.2 - 9.3.3 越狱<br>
该工具支持iOS9.2 - 9.3.3进行越狱<br>
企业级签名理论有效期1年<br>
本工具由AntSileo中文源免费提供<br>
欢迎关注AntSileo中文源微信公众号：CydiaGo<br>
欢迎使用AntSileo中文源 https://cs.nuosike.cn<br></span></h5>
          </div>
         </div>
        </div>
       </div>
      </div> 
      <!-- end -->   
       <br>          
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       </div> 
      </div> 
	</section> 

<div id="weixin" style="display:none">
    <div class="click_opacity"></div>
    <div class="to_btn">
    	<span class="span1"><img src="./pbjc/click_btn.png"></span>
        <span class="span2"><em>1</em> 点击右上角<img src="./pbjc/menu.png">打开菜单</span>
        <span class="span2"><em>2</em> 选择<img src="./pbjc/safari.png">用Safari打开下载</span>
    </div>
</div>
<!--safari提示结构结束-->
<!--软件激活授权方法提示结构-->
<!-- About Popup -->
     <br>      <br> 
  
   <link rel="stylesheet" href="./pbjc/style.css">
  
<!--软件激活授权方法提示结构结束-->
    <script type="text/javascript" src="./pbjc/zepto.min.js" charset="utf-8"></script>
<script>
$(function(){
$(document).on('click','#ios9tip', function () {
  $.popup('.popup-about');
});
$(document).on('click','#cra_tip', function () {
  $.popup('.popup-about2');
});
$(document).on('click','#cra_tip1', function () {
  $.popup('.popup-about3');
});
function is_ios9() {
	if((navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i))) {
		return Boolean(navigator.userAgent.match(/OS [9-9]_\d[_\d]* like Mac OS X/i));
	} else {
		return false;
	}
}

function is_weixin(){
	var ua = navigator.userAgent.toLowerCase();
	if(ua.match(/MicroMessenger/i)=="micromessenger") {
		return true;
	} else {
		return false;
	}
}
function show(titles,texts){
    $.modal({
	  title:  titles,
      text: texts,
      buttons: [
        {
          text: '我知道了',
          bold: true
        },
      ]
    })
}

$(document).on("click","#down",function(){
	var browser = {
		versions: function() {
			var u = navigator.userAgent, app = navigator.appVersion;
			return {
				trident: u.indexOf('Trident') > -1,
				presto: u.indexOf('Presto') > -1,
				webKit: u.indexOf('AppleWebKit') > -1,
				gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,
				mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/),
				ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
				android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1,
				iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1,
				iPad: u.indexOf('iPad') > -1,
				webApp: u.indexOf('Safari') == -1
			};
		}()
	}
	if (browser.versions.ios || browser.versions.iPhone || browser.versions.iPad) {
		//微信打开时 系统为ios
		if(is_weixin()){
			$('#weixin').show();
			return ;
		} else {
			//系统为ios  不是微信打开
          window.location.href = 'http://t.cn/EvROjRQ';
			if(is_ios9()){
				//ios9提示
				$('#ios9tip').show();
			}
		}
	} else {
		//弹出提示不是 ios 设备
		$('#down').hide();
		$('#down_tip').html("当前程序只支持苹果IOS设备");
		$('#down_tip').show();
		show("非常抱歉","当前程序只支持苹果IOS设备。");
		return ;
	}
	//下载
	window.location.href = 'holdall.mobileconfig';
	$.showPreloader();
	setTimeout(function () {
		$('#install_tips').show();
		$('#cra_tip').show();
		$('#cra_tip1').show();
		$('#down').hide();
		$.hidePreloader();
	}, 2000);
});
})
</script>
    
<script>
$(function(){
$(document).on('click','#ios9tip', function () {
  $.popup('.popup-about');
});
$(document).on('click','#cra_tip', function () {
  $.popup('.popup-about2');
});
$(document).on('click','#cra_tip1', function () {
  $.popup('.popup-about3');
});
function is_ios9() {
	if((navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i))) {
		return Boolean(navigator.userAgent.match(/OS [9-9]_\d[_\d]* like Mac OS X/i));
	} else {
		return false;
	}
}

function is_weixin(){
	var ua = navigator.userAgent.toLowerCase();
	if(ua.match(/MicroMessenger/i)=="micromessenger") {
		return true;
	} else {
		return false;
	}
}
function show(titles,texts){
    $.modal({
	  title:  titles,
      text: texts,
      buttons: [
        {
          text: '我知道了',
          bold: true
        },
      ]
    })
}

$(document).on("click","#down1",function(){
	var browser = {
		versions: function() {
			var u = navigator.userAgent, app = navigator.appVersion;
			return {
				trident: u.indexOf('Trident') > -1,
				presto: u.indexOf('Presto') > -1,
				webKit: u.indexOf('AppleWebKit') > -1,
				gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,
				mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/),
				ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
				android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1,
				iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1,
				iPad: u.indexOf('iPad') > -1,
				webApp: u.indexOf('Safari') == -1
			};
		}()
	}
	if (browser.versions.ios || browser.versions.iPhone || browser.versions.iPad) {
		//微信打开时 系统为ios
		if(is_weixin()){
			$('#weixin').show();
			return ;
		} else {
			//系统为ios  不是微信打开
          window.location.href = 'https://cs.nuosike.cn/jbak/Jailbreak/910.mobileconfig';
			if(is_ios9()){
				//ios9提示
				$('#ios9tip').show();
			}
		}
	} else {
		//弹出提示不是 ios 设备
		$('#down1').hide();
		$('#down_tip').html("当前程序只支持苹果IOS设备");
		$('#down_tip').show();
		show("非常抱歉","当前程序只支持苹果IOS设备。");
		return ;
	}
	//下载
	window.location.href = 'https://cs.nuosike.cn/jbak/Jailbreak/910.mobileconfig';
	$.showPreloader();
	setTimeout(function () {
		$('#install_tips').show();
		$('#cra_tip').show();
		$('#cra_tip').show();
		$('#down1').hide();
		$.hidePreloader();
	}, 2000);
});
})
</script>    
    
    
    
<script>
$(function(){
$(document).on('click','#ios9tip', function () {
  $.popup('.popup-about');
});
$(document).on('click','#cra_tip', function () {
  $.popup('.popup-about2');
});
$(document).on('click','#cra_tip1', function () {
  $.popup('.popup-about3');
});
function is_ios9() {
	if((navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i))) {
		return Boolean(navigator.userAgent.match(/OS [9-9]_\d[_\d]* like Mac OS X/i));
	} else {
		return false;
	}
}

function is_weixin(){
	var ua = navigator.userAgent.toLowerCase();
	if(ua.match(/MicroMessenger/i)=="micromessenger") {
		return true;
	} else {
		return false;
	}
}
function show(titles,texts){
    $.modal({
	  title:  titles,
      text: texts,
      buttons: [
        {
          text: '我知道了',
          bold: true
        },
      ]
    })
}

$(document).on("click","#down2",function(){
	var browser = {
		versions: function() {
			var u = navigator.userAgent, app = navigator.appVersion;
			return {
				trident: u.indexOf('Trident') > -1,
				presto: u.indexOf('Presto') > -1,
				webKit: u.indexOf('AppleWebKit') > -1,
				gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,
				mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/),
				ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
				android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1,
				iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1,
				iPad: u.indexOf('iPad') > -1,
				webApp: u.indexOf('Safari') == -1
			};
		}()
	}
	if (browser.versions.ios || browser.versions.iPhone || browser.versions.iPad) {
		//微信打开时 系统为ios
		if(is_weixin()){
			$('#weixin').show();
			return ;
		} else {
			//系统为ios  不是微信打开
          window.location.href = 'https://cs.nuosike.cn/jbak/Jailbreak/910.mobileconfig';
			if(is_ios9()){
				//ios9提示
				$('#ios9tip').show();
			}
		}
	} else {
		//弹出提示不是 ios 设备
		$('#down2').hide();
		$('#down_tip').html("当前程序只支持苹果IOS设备");
		$('#down_tip').show();
		show("非常抱歉","当前程序只支持苹果IOS设备。");
		return ;
	}
	//下载
	window.location.href = 'https://cs.nuosike.cn/jbak/Jailbreak/11.mobileconfig';
	$.showPreloader();
	setTimeout(function () {
		$('#install_tips').show();
		$('#cra_tip').show();
		$('#cra_tip').show();
		$('#down2').hide();
		$.hidePreloader();
	}, 2000);
});
})
</script>    
<script>
$(function(){
$(document).on('click','#ios9tip', function () {
  $.popup('.popup-about');
});
$(document).on('click','#cra_tip', function () {
  $.popup('.popup-about2');
});
$(document).on('click','#cra_tip1', function () {
  $.popup('.popup-about3');
});
function is_ios9() {
	if((navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i))) {
		return Boolean(navigator.userAgent.match(/OS [9-9]_\d[_\d]* like Mac OS X/i));
	} else {
		return false;
	}
}

function is_weixin(){
	var ua = navigator.userAgent.toLowerCase();
	if(ua.match(/MicroMessenger/i)=="micromessenger") {
		return true;
	} else {
		return false;
	}
}
function show(titles,texts){
    $.modal({
	  title:  titles,
      text: texts,
      buttons: [
        {
          text: '我知道了',
          bold: true
        },
      ]
    })
}

$(document).on("click","#down3",function(){
	var browser = {
		versions: function() {
			var u = navigator.userAgent, app = navigator.appVersion;
			return {
				trident: u.indexOf('Trident') > -1,
				presto: u.indexOf('Presto') > -1,
				webKit: u.indexOf('AppleWebKit') > -1,
				gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,
				mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/),
				ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
				android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1,
				iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1,
				iPad: u.indexOf('iPad') > -1,
				webApp: u.indexOf('Safari') == -1
			};
		}()
	}
	if (browser.versions.ios || browser.versions.iPhone || browser.versions.iPad) {
		//微信打开时 系统为ios
		if(is_weixin()){
			$('#weixin').show();
			return ;
		} else {
			//系统为ios  不是微信打开
          window.location.href = 'https://cs.nuosike.cn/jbak/Jailbreak/12.mobileconfig';
			if(is_ios9()){
				//ios9提示
				$('#ios9tip').show();
			}
		}
	} else {
		//弹出提示不是 ios 设备
		$('#down3').hide();
		$('#down_tip').html("当前程序只支持苹果IOS设备");
		$('#down_tip').show();
		show("非常抱歉","当前程序只支持苹果IOS设备。");
		return ;
	}
	//下载
	window.location.href = 'https://cs.nuosike.cn/jbak/Jailbreak/12.mobileconfig';
	$.showPreloader();
	setTimeout(function () {
		$('#install_tips').show();
		$('#cra_tip').show();
		$('#cra_tip').show();
		$('#down3').hide();
		$.hidePreloader();
	}, 2000);
});
})
</script>    
            
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
<script src="./jbyy/jquery.js"></script> 
<script src="./jbyy/zui.js"></script> 
<script src="./jbyy/js.js"></script> 
<script src="./jbyy/tongji.js"></script>

 
</div>
</body>
</html>