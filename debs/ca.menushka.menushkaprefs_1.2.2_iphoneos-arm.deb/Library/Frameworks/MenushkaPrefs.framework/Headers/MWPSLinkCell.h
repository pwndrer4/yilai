#import <Preferences/PSTableCell.h>
#import <Preferences/PSSpecifier.h>

@interface MWPSLinkCell : PSTableCell
@end